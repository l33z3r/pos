#!/bin/sh
#set -x
LC_ALL=C
export LC_ALL

version ()
{
    cat <<EOF
`basename $0`  Ver.1.0.0  Copyright (C) Seiko Epson Corporation 2010. All rights reserved.
EOF
}

press_enter_key ()
{
    echo -n "Press the Enter key."
    read REPLY
}

# Driver name
package_name="tmu-cups-1.0.0.0"

# Uninstall target
target_packages="
    tmu-cups-filter
    epson-cups-escpos
    ep-escpos
    ep-core
    ep-client
"

# Interval (sec)
sleep_sec=0


usage ()
{
cat <<EOF

    ${package_name} package uninstaller.

usage: `basename $0` [option]

  option:
	-t | --test    Test mode          (do not uninstall)
	-h | --help    Show help message  (do not uninstall)
	-u | --usage   Show usage message (do not uninstall)
	-v | --version Show version info  (do not uninstall)

uninstalled packages:  ${target_packages}
EOF
}

TEST="no"
for a in $* ; do
    case "$a" in
	"-t" | "--test"    ) TEST="yes" ;;
	"-h" | "--help"    ) version ; usage ; exit 0 ;;
	"-u" | "--usage"   )           usage ; exit 0 ;;
	"-v" | "--version" ) version ;         exit 0 ;;
	"--") break ;;
	*)
	    echo "[ERROR] Unknown option."
	    exit 255 ;;
    esac
done

check_command ()
{
    which "$1" 1>/dev/null 2>&1
}

# check package management system.
default_packager=""

for cmd in rpm dpkg ; do
    check_command $cmd
    if test $? -eq 0 ; then
	default_packager=$cmd
    fi
done
if test -z ${default_packager} ; then
    echo "[ERROR] Fatal error."
    press_enter_key
    exit 255
fi
#echo "default_packager=${default_packager}"

# check installed package.
uninstaller=""

for cmd in rpm dpkg ; do
    check_command $cmd
    if test $? -eq 0 ; then
	if test "rpm" = "$cmd" ; then
	    option="-q"
	else
	    option="-l"
	fi
	for package in ${target_packages} ; do
	    $cmd ${option} ${package} 1>/dev/null 2>&1
	    if test $? -eq 0 ; then
		uninstaller=$cmd
		break
	    fi
	done
	test "" != "${uninstaller}" && break
    fi
done

if test "" = "${uninstaller}" ; then
    uninstaller=${default_packager}
fi


# Change root.
if test 0 -ne `id -u`; then
    echo "Running the sudo command..."
    sudo $0 $*
    result=$?
    if test 1 -eq $result; then
	echo ""
        echo "[ERROR] The sudo command failed."
        echo "[ERROR] Please execute the `basename $0` again after changing to the root."
        press_enter_key
    fi
    exit $result
fi

# user confirm.
if test "no" = "${TEST}" ; then
     while true ; do
	echo -n "Uninstall ${package_name}  [y/n]? "
	read a
	answer="`echo $a | tr A-Z a-z`"
	case "$answer" in
	    y | yes ) break ;;
	    n | no  ) echo "Uninstallation canceled." ;
		press_enter_key
		exit 0 ;;
	    *       ) echo "[ERROR] Please enter \"y\" or \"n\"." ;;
	esac
    done
fi


# set uninstaller option.
if test "rpm" = "${uninstaller}" ; then
    if test "no" = "${TEST}" ; then
        option="-e"
    else
        option="-e --test"
    fi
else
    if test "no" = "${TEST}" ; then
        option="-P"
    else
        option="--no-act -P"
    fi
fi


# Do uninstall.
if test "no" = "${TEST}" ; then
    for package in ${target_packages} ; do
	echo "${uninstaller} ${option} ${package}"
	${uninstaller} ${option} ${package}
	sleep ${sleep_sec}
    done
else
    echo "* Target packages: ${target_packages}"
    echo "* Uninstall test:"
    ${uninstaller} ${option} ${target_packages}
fi

echo ""
echo "*** The uninstallation is finished. ***"
echo ""
press_enter_key

# end of file
