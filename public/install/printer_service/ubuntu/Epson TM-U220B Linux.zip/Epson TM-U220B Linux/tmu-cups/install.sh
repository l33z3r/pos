#!/bin/sh
#set -x
LC_ALL=C
export LC_ALL

version ()
{
    cat <<EOF
`basename $0`  Ver.2.0.1  Copyright (C) Seiko Epson Corporation 2010. All rights reserved.
EOF
}

usage ()
{
cat <<EOF
    Driver package installer for Linux.

usage: `basename $0` [option]

  option:
	-t | --test    Test mode          (do not install)
	-h | --help    Show help message  (do not install)
	-u | --usage   Show usage message (do not install)
	-v | --version Show version info  (do not install)

EOF
}

press_enter_key ()
{
    echo -n "Press the Enter key."
    read REPLY
}

for a in $* ; do
    case "$a" in
	"-t" | "--test"    ) TEST="yes" ;;
	"-h" | "--help"    ) version ; usage ; exit 0 ;;
	"-u" | "--usage"   )           usage ; exit 0 ;;
	"-v" | "--version" ) version ;         exit 0 ;;
	"--") break ;;
	*) ;;
    esac
done

# Change root.
if [ 0 -ne `id -u` ] ; then
    echo "Running the sudo command..."
    sudo $0 $*
    status=$?
    if [ 1 -eq ${status} ] ; then
	echo ""
        echo "[ERROR] The sudo command failed."
        echo "[ERROR] Please execute the install.sh again after changing to the root."
        press_enter_key
    fi
    exit ${status}
fi

# Set top directory.
programPath=`which $0`
topDir=`dirname "$programPath"`


#Do distribution check. (return distName)
checkDistribution ()
{
if true ; then
    # check distribution
    checkdistName=`lsb_release -d 2>/dev/null`
    distName=`echo "$checkdistName" | awk '{print $2 "-" $3}'`
else
    # check distribution
    lsb_release -i > /dev/null 2>&1
    if [ 0 -eq $? ] ; then
        os="`lsb_release -i | sed -e '\
s,^.*\t,,;\
s,(.*),,g;\
s,(,,g;\
s,),,g;\
s, ,_,g;\
s,/,_,g;\
s,-,_,g;\
s,_*$,,\
'`"
	ver=`lsb_release -r | sed -e 's,^.*\t,,;s, ,_,g'`
	distName=$os-$ver
    else
	if [ -f /etc/issue ] ; then
	    distName="`cat /etc/issue | sed -n -e '/[A-z].*/p' | head -1 | sed -e '\
s,\\\\.*$,,;\
s,(.*),,g;\
s,(,,g;\
s,),,g;\
s, ,_,g;\
s,/,_,g;\
s,-,_,g;\
s,_*$,,\
'`"
	else
	    distName="Unknown"
	fi
    fi
fi
}


#The Architecture is checked.
checkArchitecture () {
    #Select Architecte
    checkArchName=`uname -m`

    case "$checkArchName" in
	"i386" | "i486") archName="i386" ;;
	"i586" | "i686") archName="i586" ;;
	"amd64" | "x86_64") archName="x86_64" ;;
    *) archName="" ;;
    esac
}


#Packages installation
packageInstall ()
{
    # Get list filename.
    list="$1"
    status=0

    [ "yes" = "$TEST" ] && echo "* Package list file = ${list}"

    if [ -f "${list}" ] ; then

	packageType=`basename ${list} | sed -e 's,\.list$,,' | awk -F- '{ print $4 }'`

	case "${packageType}" in
	    "RPM")
		installCommand="rpm -U"
		[ "yes" = "$TEST" ] && installCommand="rpm -U --test"
		;;
	    "DEB")
		installCommand="dpkg -i --no-force-downgrade"
		[ "yes" = "$TEST" ] && installCommand="dpkg --no-act -i --no-force-downgrade"
		;;
	    *)
		echo "[ERROR] Fatal error."
		echo "[ERROR] Package installation failed."
		press_enter_key
		exit 255
		;;
	esac

	cd $topDir

	if [ "yes" = "${TEST}" ] ; then
		echo "* Target packages:"
		ls -1 `cat ${list}`
		echo "* Install test:"
		$installCommand `cat ${list}`
		status=0
	else
	    for file in `cat ${list}` ; do
		$installCommand "$topDir/$file"
	    done
	    status=$?
	fi

    else
	echo "[ERROR] cannot access ${list}: No such file."
	echo "[ERROR] Package installation failed."
	press_enter_key
	exit 255
    fi
    return ${status}
}

get_splitListName ()
{
    list=`basename $1 | sed -e 's,\.list$,,'`

    dist=`echo ${list} | awk -F- '{ print $1 }' | sed -e 's,_, ,g'`
    rel=`echo ${list} | awk -F- '{ print $2 }'`
    arch=`echo ${list} | awk -F- '{ print $3 }'`
#    pkg=`echo ${list} | awk -F- '{ print $4 }'`

    case "$arch" in
	"i386" | "i486" | "i586" | "i686") displayArch="x86(32bit)" ;;
	"amd64" | "x86_64") displayArch="x86_64(64bit)" ;;
        *) displayArch="$arch" ;;
    esac

    splitListName="${dist} ${rel} ${displayArch}"
}

# User select number (255 is error)
get_number ()
{
    read line

    n=`expr "${line}" \* 1 2>/dev/null`
    [ $? -ge 2 ] && return 255

    return $n
}

select_list_file ()
{
    number=0
    endStrings=""

    while true ; do
	echo ""
	echo "Please select your distribution."

	endStrings="Select number [0(cancel)/"

	count=0
	for list in `ls -1 $topDir/.install/*.list | LC_ALL=C sort` ; do

	    get_splitListName "$list"

	    count=`expr $count + 1`

	    echo "$count.${splitListName}"

	    if [ 1 -eq $count ] ; then
		endStrings="$endStrings$count"
	    else
		endStrings="$endStrings/$count"
	    fi
	done

	echo -n "${endStrings}]? "

	get_number
	number=$?

	if [ 0 = $number ] ; then
	    echo "Installation canceled."
	    press_enter_key
	    exit 0
	fi

	if [ ${number} -le ${count} ] ; then

	    i=0
	    selectedListFile=""
	    for list in `ls -1 $topDir/.install/*.list | LC_ALL=C sort` ; do

		i=`expr $i + 1`

		if [ ${number} -eq $i ] ; then
		    selectedListFile="$list"
		    break ;
		fi
	    done

	    if [ -n "${selectedListFile}" ] ; then
		break
	    fi
	fi

	echo "[ERROR] Please input a correct number."
    done
}

#
# MAIN
#

#Function that calls check on distribution.
distName=
checkDistribution
[ "yes" = "$TEST" ] && echo "* This distribution is \"$distName\""

#Architecture that calls check on distribution.
archName=
checkArchitecture
[ "yes" = "$TEST" ] && echo "* Machine Architecture is \"$archName\""

targetFile=`ls -1 $topDir/.install/$distName-$archName-*.list 2> /dev/null`

if [ -n "$targetFile" -a -f "$targetFile" ] ; then

    while true ; do

	get_splitListName "${targetFile}"

	echo -n "Install ${splitListName} [y/n]? "
	read a

	answer="`echo $a | tr A-Z a-z`"

	case "$answer" in
	    y | yes )
		break
		;;
	    n | no  )
		select_list_file
		targetFile="${selectedListFile}"
		break
		;;
	    * )
		echo "[ERROR] Please enter \"y\" or \"n\"."
		;;
	esac
    done
else
    select_list_file
    targetFile="${selectedListFile}"
fi

#Packages installation
packageInstall ${targetFile}

echo ""
echo "*** The installation is finished. ***"
echo ""
press_enter_key

# end of file
