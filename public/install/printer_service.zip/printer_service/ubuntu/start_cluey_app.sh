#!/bin/sh
google-chrome --kiosk
